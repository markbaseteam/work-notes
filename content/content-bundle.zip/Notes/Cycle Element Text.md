```js
HTMLElement.prototype.cycleTextContent = function () {
    if(arguments.length < 1) return false;
    for (var i = 0; i < arguments.length; i++) {
        if(arguments[i] === this.textContent) {
            var newIndex = (i + 1) % arguments.length;
            this.textContent = arguments[newIndex];
            return newIndex;
        }
    }
    this.textContent = arguments[0];
    return 0;
}
```