# SCSS Errors and Fixes

## Incompatible units: '%' and 'px'. https://github.com/sass/node-sass/issues/2815

**Problematic with sass**
```width: max(37%, 215px);```

**Valid with sass**
```width: #{"max(37%, 215px)"};```

**Solution**
Wrap with #{"Mixed unit property here"};

---

## Next error template

**Problematic with sass**
```Code Sample```

**Valid with sass**
```Code sample```

**Solution**
Solution