# Void Elements

## What


The term void elements is used to designate elements that must be [empty](https://dev.w3.org/html5/html-author/#empty-element "empty element"). These requirements _only_ apply to the HTML syntax. In XHTML, all such elements are treated as [normal elements](https://dev.w3.org/html5/html-author/#normal-elements-0), but must be marked up as empty elements.

These elements are forbidden from containing any content at all. In HTML, these elements have a [start tag](https://dev.w3.org/html5/html-author/#start-tag) only. The [self-closing tag](https://dev.w3.org/html5/html-author/#self-closing-tag) syntax may be used. The [end tag](https://dev.w3.org/html5/html-author/#end-tag) must be omitted because the element is automatically closed by the parser.

[W3 Spec](https://dev.w3.org/html5/html-author/#void)


A void element is an element whose [content model](https://w3c.github.io/html-reference/syntax.html#content-model) never allows it to have [contents](https://w3c.github.io/html-reference/syntax.html#contents) under any circumstances. Void elements can have attributes.


## Which Elements

The following is a complete list of the void elements in HTML:

- [area](https://w3c.github.io/html-reference/area.html#area)
- [base](https://w3c.github.io/html-reference/base.html#base)
-  [br](https://w3c.github.io/html-reference/br.html#br)
- [col](https://w3c.github.io/html-reference/col.html#col)
- [command](https://w3c.github.io/html-reference/command.html#command)`
- [embed](https://w3c.github.io/html-reference/embed.html#embed) 
- [hr](https://w3c.github.io/html-reference/hr.html#hr)
- [img](https://w3c.github.io/html-reference/img.html#img)
- [input](https://w3c.github.io/html-reference/input.html#input)
- [keygen](https://w3c.github.io/html-reference/keygen.html#keygen)
- [link](https://w3c.github.io/html-reference/link.html#link)
- [meta](https://w3c.github.io/html-reference/meta.html#meta)
- [param](https://w3c.github.io/html-reference/param.html#param)
- [source](https://w3c.github.io/html-reference/source.html#source)
- [track](https://w3c.github.io/html-reference/track.html#track)
- [wbr](https://w3c.github.io/html-reference/wbr.html#wbr)

[W3C Spec](https://w3c.github.io/html-reference/syntax.html#void-element)


## Important  to know

Psuedo elements like **::before and ::after will not work** on void elements

