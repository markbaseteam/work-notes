## Close local

## Delete ~/Library/Application Support/Local/run/router

## Restart local

## Trust certificate

# Fixed.



