# General Wordpress Notes

# Custom post types

Flush the permalinks to get rid of the 404 error! Super frusterating to forget