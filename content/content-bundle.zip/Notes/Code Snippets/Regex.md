# Regex snippets

### [[Notes/Code Snippets/JavaScript/Regex]]