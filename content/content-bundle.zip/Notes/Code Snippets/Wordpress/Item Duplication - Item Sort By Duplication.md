https://facetwp.com/how-to-prevent-duplicate-results/#using-a-custom-wp_query

Look out for the following scenarios that are most often the cause of multiple posts sharing the same value for the `orderby` field, resulting in duplicate posts:

1. Posts were imported (for example with [WP All Import](https://facetwp.com/help-center/using-facetwp-with/wp-all-import/) or [WebToffee Import Export](https://facetwp.com/help-center/using-facetwp-with/webtoffee-product-import-export-for-woocommerce/)), and no specific `orderby` argument is set in the query, or it is set to `date`. Imported posts often share the exact same post date, and [by default, WordPress will order queries by post date](https://developer.wordpress.org/reference/classes/wp_query/#order-orderby-parameters).
2. The `orderby` argument is set to `menu_order`. Note that the “menu order” is not just the order of your posts in the backend. It is a post setting that has to be specifically set for each post, and it defaults to `0`. It can also be set with plugins like [Post Types Order](https://facetwp.com/help-center/using-facetwp-with/post-types-order/).
3. The `orderby` argument is set to a specific custom field (with `meta_value` or `meta_value_num`) and multiple posts have the same value for that field, or the field is empty or does not exist for multiple posts.
4. The `orderby` argument is set to `rand` to create a random order. Even with a fallback sort order, the results will be re-randomized on each facet interaction (including pagination), which will lead to duplicate posts and other issues. [The solution can be found here](https://facetwp.com/random-ordering-in-facetwp/).

### [](https://facetwp.com/how-to-prevent-duplicate-results/#duplicate-entries-when-using-a-sort-facet "Copy link to this section")

```php
$args = [
  // ... your arguments
  'orderby' => [
    'date' => 'DESC', // Primary sort: by post date
    'ID'   => 'DESC'  // Secondary, fallback sort: by post ID
  ],
  // ... your arguments
];
```

Sort by Rand

```php
$args = [
  'post_type' => [
    "post"
  ],
  'post_status' => [
    'publish'
  ],
  'posts_per_page' => 10,
  'orderby' => [
    'rand' => 'ASC', // Sort by random
    'title' => 'ASC' // Use post title as a fallback sort
  ]
];
```

