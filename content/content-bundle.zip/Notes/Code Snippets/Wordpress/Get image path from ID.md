If we want the original image use


```php
wp_get_original_image_path( int $attachment_id, bool $unfiltered = false )
```

https://developer.wordpress.org/reference/functions/wp_get_original_image_path/

**Works with email attachments**