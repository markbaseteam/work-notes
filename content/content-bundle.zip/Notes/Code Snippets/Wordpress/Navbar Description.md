# Add a description to the navbar

```php
function my_wp_nav_menu_objects( $items, $args ) {

// loop

foreach( $items as &$item ) {

// vars

$description = get_field('description', $item);

if($description) {

$item->description = $description;

}

}

// return

return $items;

}
```

In `wp-bootstrap-navwalker.php` add in this code at the end of the `start_el` function

```php
$item_output .= $args->link_before . apply_filters( 'the_title', $item->title, $item->ID ) . $args->link_after;

$item_output .= ( $args->has_children && 0 === $depth ) ? ' <span class="caret"></span></a>' : '</a>';

$item_output .= $item->description ? '<p class="link-description">' . $item->description . '</p>' : '';

$item_output .= $args->after;

$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
```
