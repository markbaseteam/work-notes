# Is logged in user an administrator?

```php
function is_site_admin(){
    return in_array('administrator',  wp_get_current_user()->roles);
}
```