# Code Snippets

Copy paste code snippets for repetitive things at work

### Check for X template

**functions.php**

```php
function has_template(string $templateName) : bool {
  return pathinfo(get_page_template())['basename'] === 'page-compliance.php';
}
```

*Use function*

```php
<?php if (has_template('template.php’')) : ?>
  // Content here
<?php endif ?>
```

### Define a template

*Comment is necessary to register a template into the list of available templates*

File name

template-$templateName.php

```php
<?php // Template Name: TemplateName
include('page.php'); ?>
```

### Search by title, case insensitive

```php
add_filter( 'posts_where', 'title_filter', 10, 2 );

// Filter by title
function title_filter($where, $wp_query) {
    global $wpdb;

    if($search_term = $wp_query->get( 'search_title' )){
        /*using the esc_like() in here instead of other esc_sql()*/
        $search_term = $wpdb->esc_like($search_term);
        $search_term = ' \'%' . $search_term . '%\'';
        $where .= ' AND LOWER( ' . $wpdb->posts . '.post_title ) LIKE ' . strtolower($search_term);
    }

    return $where;
}

$the_query = new WP_Query(
    [
        'posts_per_page' => -1,
        'search_title'   => "TITLE HERE",
        'post_type'      => ['example type'], // optional types to filter for
        'post_status'    => 'publish', // only published items
        // 'orderby'        => 'Column name, ex: title',
        // 'order'          => 'ASC'
    ]
);
```

# Create accessible buttons from any element
## This is bad don't use

Make sure to set role="button" and set tabindex="0" to allow tabbing. Maybe add this automatically in the future also maybe even add an action when clicked here.

```js
/*
*   This content is licensed according to the W3C Software License at
*   https://www.w3.org/Consortium/Legal/2015/copyright-software-and-document
*
*   JS code for the button design pattern
*
*   Code has been modified to fix deprecated code and add accessibility to whatever we need to be a button - make sure to set role="button" and set tabindex="0" to allow tabbing
*   Original code from
*   @link https://www.w3.org/TR/wai-aria-practices/examples/button/js/button.js
*   See https://www.w3.org/TR/wai-aria-practices/examples/button/button.html for more details
*/

var SPACE = ' ';
var ENTER = 'Enter';

function init (...buttons) {
    for(var button of buttons) {
        if(typeof button.btn === "string")
            button.btn = document.querySelector(button.btn);
        if(!button.btn) continue;
        console.log({button});
        // var {btn, isToggleButton} = button;
        var btn = button.btn;
        var isToggleButton = button.isToggleButton;
        if(!isToggleButton) {
            // btn.addEventListener('click', activateActionButton);
            btn.addEventListener('keydown', actionButtonKeydownHandler);
            btn.addEventListener('keyup', actionButtonKeyupHandler);
        } else {
            btn.addEventListener('click', toggleButtonClickHandler);
            btn.addEventListener('keydown', toggleButtonKeydownHandler);
            btn.addEventListener('keyup', toggleButtonKeyupHandler);
        }
    }
}

/**
 * Activates the action button with the enter key.
 *
 * @param {KeyboardEvent} event
 */
function actionButtonKeydownHandler (event) {
  // The action button is activated by space on the keyup event, but the
  // default action for space is already triggered on keydown. It needs to be
  // prevented to stop scrolling the page before activating the button.
  if (event.key === SPACE) {
    event.preventDefault();
  }
  // If enter is pressed, activate the button
  else if (event.key === ENTER) {
    event.preventDefault();
    activateActionButton(event.target);
  }
}

/**
 * Activates the action button with the space key.
 *
 * @param {KeyboardEvent} event
 */
function actionButtonKeyupHandler (event) {
  if (event.key === SPACE) {
    event.preventDefault();
    activateActionButton(event.target);
  }
}

function activateActionButton (button) {
    $(button).trigger('click'); // for some reason jquery click works but not button.click()
}

/**
 * Toggles the toggle button's state if it's actually a button element or has
 * the `role` attribute set to `button`.
 *
 * @param {MouseEvent} event
 */
function toggleButtonClickHandler (event) {
  if (
    event.currentTarget.tagName === 'button' ||
    event.currentTarget.getAttribute('role') === 'button'
  ) {
    toggleButtonState(event.currentTarget, true);
  }
}

/**
 * Toggles the toggle button's state with the enter key.
 *
 * @param {KeyboardEvent} event
 */
function toggleButtonKeydownHandler (event) {
  if (event.key === SPACE) {
    event.preventDefault();
  }
  else if (event.key === ENTER) {
    event.preventDefault();
    toggleButtonState(event.currentTarget, false);
  }
}

/**
 * Toggles the toggle button's state with space key.
 *
 * @param {KeyboardEvent} event
 */
function toggleButtonKeyupHandler (event) {
  if (event.key === SPACE) {
    event.preventDefault();
    toggleButtonState(event.currentTarget, false);
  }
}

/**
 * Toggles the toggle button's state between *pressed* and *not pressed*.
 *
 * @param {HTMLElement} button
 */
function toggleButtonState (button, wasClicked) {
  var isAriaPressed = button.getAttribute('aria-pressed') === 'true';

  button.setAttribute('aria-pressed', isAriaPressed ? 'false' : 'true');

  if(!wasClicked) button.click();
}

function makeAccessibleButtons(...buttons) {
    init(
    {
        btn: "header.main .navbar-nav li.menu-item-5577 a",
        isToggleButton: true
    },
 ...buttons);
}

window.onload = makeAccessibleButtons;
```

# Removing spam orders from a specific date that failed

Make a backup first, date should be like 2021-07-10 or something

```sql
DELETE FROM {WOOCOMMERCE PREFIX}posts WHERE post_type = 'shop_order' AND post_date LIKE '{DATE}%' AND post_status = 'wc-failed';
```

Then clean up everything

```sql
DELETE FROM {WOOCOMMERCE PREFIX}postmeta WHERE post_id NOT IN (SELECT id FROM {WOOCOMMERCE PREFIX}posts);
DELETE FROM {WOOCOMMERCE PREFIX}term_relationships WHERE object_id NOT IN (SELECT id FROM {WOOCOMMERCE PREFIX}posts)
```


# Get list of terms for a post

```php
$termObjects = wp_get_post_terms((get_post())->ID, $TAXONOMY_NAME);
$termList = [];
foreach($termObjects as $term) {
    $termList[] = $term->name;
}
$return = implode(", ", $termList);
```

# Foreach on every post from WP CLI
Example is for Woocommerce, we add a weight to every product, weight is stored in post meta.

wp eval '$q = new WP_Query(["post_type" => ["product"], "posts_per_page" => -1]); foreach($q->posts as $p) { add_post_meta($p->ID, '_weight', 1, true); }'

# jQuery Ajax function without jQuery

```js
function ajax(option) { // $.ajax(...) without jquery.
    if (typeof(option.url) == "undefined") {
        try {
            option.url = location.href;
        } catch(e) {
            var ajaxLocation;
            ajaxLocation = document.createElement("a");
            ajaxLocation.href = "";
            option.url = ajaxLocation.href;
        }
    }
    if (typeof(option.type) == "undefined") {
        option.type = "GET";
    }
    if (typeof(option.data) == "undefined") {
        option.data = null;
    } else {
        var data = "";
        for (var x in option.data) {
            if (data != "") {
                data += "&";
            }
            data += encodeURIComponent(x)+"="+encodeURIComponent(option.data[x]);
        };
        option.data = data;
    }
    if (typeof(option.statusCode) == "undefined") { // 4
        option.statusCode = {};
    }
    if (typeof(option.beforeSend) == "undefined") { // 1
        option.beforeSend = function () {};
    }
    if (typeof(option.success) == "undefined") { // 4 et sans erreur
        option.success = function () {};
    }
    if (typeof(option.error) == "undefined") { // 4 et avec erreur
        option.error = function () {};
    }
    if (typeof(option.complete) == "undefined") { // 4
        option.complete = function () {};
    }
    typeof(option.statusCode["404"]);

    var xhr = null;

    if (window.XMLHttpRequest || window.ActiveXObject) {
        if (window.ActiveXObject) { try { xhr = new ActiveXObject("Msxml2.XMLHTTP"); } catch(e) { xhr = new ActiveXObject("Microsoft.XMLHTTP"); } }
        else { xhr = new XMLHttpRequest(); }
    } else { alert("Votre navigateur ne supporte pas l'objet XMLHTTPRequest..."); return null; }

    xhr.onreadystatechange = function() {
        if (xhr.readyState == 1) {
            option.beforeSend();
        }
        if (xhr.readyState == 4) {
            option.complete(xhr, xhr.status);
            if (xhr.status == 200 || xhr.status == 0) {
                option.success(xhr.responseText);
            } else {
                option.error(xhr.status);
                if (typeof(option.statusCode[xhr.status]) != "undefined") {
                    option.statusCode[xhr.status]();
                }
            }
        }
    };

    if (option.type == "POST") {
        xhr.open(option.type, option.url, true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
        xhr.send(option.data);
    } else {
        xhr.open(option.type, option.url+option.data, true);
        xhr.send(null);
    }

}
```

# Remove query string param from Javascript

```js
const params = new URLSearchParams(document.location.search)
params.delete("param");
const newParams = params.toString();
if(newParams) {
    window.history.replaceState(null, null, "?" + newParams);
} else {
    window.history.replaceState(null, null, window.location.pathname);
}
```

# Clear whole query string

```js
window.history.replaceState(null, null, window.location.pathname);
```



### [[Javascript Prototypes]]


### [[Adding an options page]]

^94edbc


# Remove domain redirect from cache

```js
fetch('https://iwanttoremovethis.com', {method: 'post'}).then(() => {})
```


