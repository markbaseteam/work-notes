
### Send email with this


```php
wp_mail("adam@solutionagency.net", "Debug", var_dump_string($var), "Content-Type: text/html");
```

HTML Email because we want the var dump code to look pretty

### This function is for var dumping into the email

```php
function var_dump_string($var) {

	ob_start();
	
	var_dump($var);
	
	$dump = ob_get_clean();
	
	return $dump;

}
```

### Catch the email with MailHog or something

*Success!*

![[Screen Shot 2022-04-06 at 11.09.22 AM.png]]