This is edit of testing plugin with all email types

![[woocommerce-email-test.zip]]