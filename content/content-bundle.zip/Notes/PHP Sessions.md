# After writing to a session

**Always make sure to close it**

**session_write_close**():