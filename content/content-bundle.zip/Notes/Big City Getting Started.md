# Enabling Script Debug

In wp-config.php add

`define( 'SCRIPT_DEBUG', true );`

after

`/* Add any custom values between this line and the "stop editing" line. */`