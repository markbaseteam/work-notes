Stack overflow

https://stackoverflow.com/a/65231087/14566339


Working Xdebug settings

```ini
xdebug.remote_enable=1

xdebug.remote_connect_back=Off

xdebug.profiler_enable=0

xdebug.mode=debug,develop

xdebug.start_with_request = yes
```

```
; This should be the same as above but more up to date
; xdebug.profile_enable -> xdebug.mode=profile
; xdebug.remove_enable -> xdebug.mode=debug
xdebug.remote_connect_back=Off
xdebug.mode=debug,develop
xdebug.start_with_request = yes
```

Mode:

debug: turns on step debuggers
develop: turns on fancy var dumps and stack traces

https://xdebug.org/docs/


**When troubleshooting, restart the website after any updates made to php.ini.hbs**


Our launch.json

```json
{
	"version": "0.2.0",
	
	"configurations": [
	
		{
		
		"name": "Listen for Xdebug 3.0 (Local)",
		
		"type": "php",
		
		"request": "launch",
		
		"port": 9003,
		
		"xdebugSettings": {
		
			"max_children": 128,
			
			"max_data": 1024,
			
			"max_depth": 3,
			
			"show_hidden": 1
			
		}
	
		},
	
		{
		
			"name": "Listen for Xdebug (Local)",
			
			"type": "php",
			
			"request": "launch",
			
			"port": 9000,
			
			"xdebugSettings": {
			
				"max_children": 128,
				
				"max_data": 1024,
				
				"max_depth": 3,
				
				"show_hidden": 1
			
			}
		
		},
	
		{
			
			"name": "Launch currently open script",
			
			"type": "php",
			
			"request": "launch",
			
			"program": "${file}",
			
			"cwd": "${fileDirname}",
			
			"port": 9000,
			
			"xdebugSettings": {
			
				"max_children": 128,
				
				"max_data": 1024,
				
				"max_depth": 3,
				
				"show_hidden": 1
			
			}
			
		}
	
	]

}
```

