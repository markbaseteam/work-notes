https://solutionagency.teamwork.com/#/tasks/34245713
All that needs to be done is adding a phone number to call if it's not the csr. Use the 1800 phone number  [1-800-516-4106](tel:+1-800-516-4106)

https://solutionagency.teamwork.com/#/tasks/34316162
Right now it only shows credit card, add the other options, ACH/Check - these are the same thing

https://solutionagency.teamwork.com/#/tasks/34316118
Push footer to bottom, Jena says to use a min height of 100 view height is fine

https://solutionagency.teamwork.com/#/tasks/34269981
For location displaying, make two branches for these potential solutions

Banner that displays location, could be above or below

AND ALTERNATIVELY

Remove schedule service button, replace with location

This is really just list item 1 for now, ignore the others until we get this finished

https://solutionagency.teamwork.com/#/tasks/34652681

Easiest option is a copy change to say that it includes a free furnace filter

But email the client to check they don't need a checkbox saying I want a furnace filter or something


# Staging / Dev

Put the payment processor into testing mode
Woocommerce -> Export Order -> Schedule Jobs -> Deactive all the order exports


## Additionally
Reactivate Sucuri on local and see if that breaks orders














