## Guide

http://docs.primax.com/bitbucket-pipelines/


## Enable Pipelines

https://bitbucket.org/primax/richter-phillips/admin/addon/admin/pipelines/settings


## Generate SSH Keys

Go here, and leave it open until the end of this section

https://bitbucket.org/primax/richter-phillips/admin/addon/admin/pipelines/ssh-keys


Copy key and paste into Siteground -> Devs -> SSH Keys Manager -> Import

Click on SSH key you just imported (Three dots under actions)

Click SSH Credentials

Should be something like

Host: website.domain
Username: random crap
Port: 18765


Back in the SSH section, fetch known hosts, using the host and port like website.domain:18765

Once the fingerprint is fetched, click add host


## Create this file - tweak according to needs


### bitbucket-pipelines.yml

```yml
image: atlassian/default-image:2

  

pipelines:

branches:

production:

- step:

name: Deploy to Production

deployment: production

script:

- rsync -azvP --stats --exclude={'node_modules/*',"bitbucket-pipelines.yml",'scss/*'} -e 'ssh -p18765' $BITBUCKET_CLONE_DIR/ $PROD_USER@$PROD_DOMAIN:$PROD_PATH

- ssh -p18765 -tt $PROD_USER@$PROD_DOMAIN "cd $PROD_WPPATH && wp sg purge"
```


## Add Repo Variables in Bitbucket

https://bitbucket.org/primax/richter-phillips/admin/addon/admin/pipelines/repository-variables


Should look like this:


![[Screen Shot 2022-04-06 at 2.43.28 PM.png]]


**It is 99% going to be the same format above BUT if you need to troubleshoot the next bit should help**

I recommend creating a SSH key if you don't have one, then importing that in the same manner as above. You'll then be able to login to the servers shell which will help you get the next part right.

PROD_WPPATH varies based on the URL you SSH Into, PROD_PATH is based on PROD_WPPATH and is the full directory to get to your theme, start this with your PROD_WPPATH

PROD_USER and PROD_DOMAIN are from SSH credentials in step 2

Make sure Siteground optimizer is installed and active or else the sg command will fail